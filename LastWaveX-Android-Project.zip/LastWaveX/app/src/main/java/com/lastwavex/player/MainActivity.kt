package com.lastwavex.player

import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer

private val Ink = Color(0xFF09090D)
private val Panel = Color(0xFF17171F)
private val Accent = Color(0xFFFF375F)
private val Muted = Color(0xFF9B9BA8)

class MainActivity : ComponentActivity() {
    private var player: ExoPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        player = ExoPlayer.Builder(this).build()
        setContent { LastWaveApp(player = player, displayName = { uri -> getDisplayName(uri) }) }
    }

    private fun getDisplayName(uri: Uri): String {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) return c.getString(0) ?: "Selected audio"
        }
        return uri.lastPathSegment ?: "Selected audio"
    }

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }
}

@Composable
private fun LastWaveApp(player: ExoPlayer?, displayName: (Uri) -> String) {
    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var title by remember { mutableStateOf("Choose a song") }
    var playing by remember { mutableStateOf(false) }
    var selectedTab by remember { mutableStateOf("Home") }
    var message by remember { mutableStateOf("Your music, your way.") }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
        }
        player?.addListener(listener)
        onDispose { player?.removeListener(listener) }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            selectedUri = uri
            title = displayName(uri)
            message = if (title.substringAfterLast('.', "").equals("flac", true))
                "FLAC file selected • lossless format" else "Local audio selected"
            player?.setMediaItem(MediaItem.fromUri(uri))
            player?.prepare()
            player?.play()
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Ink, surface = Panel, primary = Accent,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(containerColor = Ink, bottomBar = {
            NavigationBar(containerColor = Color(0xFF111116), contentColor = Color.White) {
                NavigationBarItem(selected = selectedTab == "Home", onClick = { selectedTab = "Home" },
                    icon = { Icon(Icons.Default.Home, null) }, label = { Text("Listen") }, colors = navColors())
                NavigationBarItem(selected = selectedTab == "Search", onClick = { selectedTab = "Search" },
                    icon = { Icon(Icons.Default.Search, null) }, label = { Text("Search") }, colors = navColors())
                NavigationBarItem(selected = selectedTab == "Library", onClick = { selectedTab = "Library" },
                    icon = { Icon(Icons.Default.LibraryMusic, null) }, label = { Text("Library") }, colors = navColors())
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().background(Ink).padding(padding).padding(horizontal = 22.dp)) {
                Spacer(Modifier.height(22.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("LASTWAVE", color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                        Text("X", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Black, lineHeight = 36.sp)
                    }
                    Box(Modifier.size(44.dp).clip(CircleShape).background(Panel), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.FavoriteBorder, contentDescription = "Favorites", tint = Color.White)
                    }
                }
                Spacer(Modifier.height(24.dp))
                when (selectedTab) {
                    "Search" -> {
                        Text("Find your sound", fontSize = 26.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Text("Online search will be added after connecting a music provider that permits access and lossless downloads.", color = Muted, lineHeight = 22.sp)
                        Spacer(Modifier.height(18.dp))
                        Button(onClick = { picker.launch(arrayOf("audio/*")) }, colors = ButtonDefaults.buttonColors(containerColor = Accent)) {
                            Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(8.dp)); Text("Choose local audio")
                        }
                    }
                    "Library" -> {
                        Text("Your library", fontSize = 26.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Text("Pick audio files from your phone to start your collection.", color = Muted)
                        Spacer(Modifier.height(18.dp))
                        Button(onClick = { picker.launch(arrayOf("audio/*")) }, colors = ButtonDefaults.buttonColors(containerColor = Accent)) {
                            Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(8.dp)); Text("Import music")
                        }
                    }
                    else -> {
                        Text("Made for your", color = Muted, fontSize = 15.sp)
                        Text("music mood.", fontSize = 29.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(18.dp))
                        Box(Modifier.fillMaxWidth().height(190.dp).clip(RoundedCornerShape(28.dp)).background(
                            Brush.linearGradient(listOf(Color(0xFF4C1732), Color(0xFF1B1B2B), Color(0xFF101015)))
                        )) {
                            Column(Modifier.align(Alignment.Center).padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("∞", color = Accent, fontSize = 54.sp, fontWeight = FontWeight.Light)
                                Text("YOUR SOUND. NO LIMITS.", color = Color.White, fontSize = 11.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        Spacer(Modifier.height(24.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Play from your phone", fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            IconButton(onClick = { picker.launch(arrayOf("audio/*")) }) {
                                Icon(Icons.Default.FolderOpen, "Choose audio", tint = Accent)
                            }
                        }
                        Text("Select a FLAC, MP3, or other supported audio file.", color = Muted, fontSize = 14.sp)
                        Spacer(Modifier.height(16.dp))
                        Button(onClick = { picker.launch(arrayOf("audio/*")) }, modifier = Modifier.fillMaxWidth().height(52.dp),
                            shape = RoundedCornerShape(16.dp), colors = ButtonDefaults.buttonColors(containerColor = Accent)) {
                            Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(9.dp)); Text("Choose a song", fontWeight = FontWeight.Bold)
                        }
                    }
                }
                Spacer(Modifier.weight(1f))
                if (selectedUri != null) {
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Panel).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)).background(Brush.linearGradient(listOf(Accent, Color(0xFF5C2B87)))), contentAlignment = Alignment.Center) {
                            Text("♪", fontSize = 28.sp, color = Color.White)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(message, color = Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        IconButton(onClick = {
                            if (player?.isPlaying == true) player.pause() else player?.play()
                        }) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, "Play or pause", tint = Accent) }
                    }
                } else {
                    Text("LASTWAVE X • EARLY BUILD", color = Color(0xFF666672), fontSize = 10.sp, letterSpacing = 1.5.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
                }
                Spacer(Modifier.height(12.dp))
            }
        }
    }
}

@Composable
private fun navColors() = NavigationBarItemDefaults.colors(
    selectedIconColor = Accent, selectedTextColor = Accent,
    indicatorColor = Color(0xFF34202A), unselectedIconColor = Muted, unselectedTextColor = Muted
)
