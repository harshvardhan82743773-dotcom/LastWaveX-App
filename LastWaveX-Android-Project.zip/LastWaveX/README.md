# LastWave X — early Android project

This is a starter Android Studio project for a dark, Apple Music-inspired music player.

## Included in this first build
- Android app UI with Listen, Search, and Library tabs
- Select audio files using Android's document picker (no broad storage permission required)
- Playback through AndroidX Media3/ExoPlayer
- FLAC file selection and local playback support where the Android decoder supports the file

## Not included yet
- Online music catalogue/search
- Direct online FLAC downloads
- Synced lyrics, artwork lookup, playlists, or history persistence

Those online features require selecting and integrating an authorized provider/API that explicitly supports lossless audio and downloads. A FLAC extension alone does not prove the contents are genuinely lossless.

## Build
Open this folder in Android Studio on a computer, sync Gradle, then Build > Build APK(s). This ZIP is source code, not an installable APK. A phone-only build path still needs a compatible Android build environment/app and has not been tested here.
